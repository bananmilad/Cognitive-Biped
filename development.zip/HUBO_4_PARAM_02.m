%%IN THE NAME OF ....
%%
%%HUBO_4 PARAM.............................................................
%%
%%WORLD PARAM..............................................................
plane_x=100;
plane_y=50;
plane_z=0.0250;
%%
%%BODY PARAM...............................................................
torso_w=0.24;
torso_l=0.1;
torso_h=0.4;
leg_w=0.02;
leg_l=0.02;
u_leg_h=0.4;
l_leg_h=0.38;
ankle_l=0.02;
ankle_w=0.02;
ankle_h=0.05;
%foot_l=0.1;
%foot_l=0.2;
foot_l=0.2;
% foot_w=0.05;
foot_w=0.2;
foot_h=0.02;
L1 = 0.12; %base to hip angle
L2 = 0; 
L3 = 0.4; %hip to knee
L4 = 0.38; %knee to foot
L5 = 0;
%%
A0to1Rotation=[1 0 0 ;0 1 0;0 0 1];
A0to1Translation=[L1 0 -L2];
A1to2Rotation=[1 0 0 ;0 0 1;0 -1 0];
A1to2Translation=[0 0 0];
A2to3Rotation=[1 0 0 ;0 0 1;0 -1 0];
A2to3Translation=[0 0 0];
A3to4Rotation=[1 0 0 ;0 1 0;0 0 1];
A3to4Translation=[L3 0 0];
A4to5Rotation=[1 0 0 ;0 1 0;0 0 1];
A4to5Translation=[L4 0 0];
A5to6Rotation=[1 0 0 ;0 0 -1;0 1 0];
A5to6Translation=[0 0 0];
%%
B0to1Rotation=[1 0 0 ;0 1 0;0 0 1];
B0to1Translation=[-L1 0 -L2];
B1to2Rotation=[1 0 0 ;0 0 1;0 -1 0];
B1to2Translation=[0 0 0];
B2to3Rotation=[1 0 0 ;0 0 1;0 -1 0];
B2to3Translation=[0 0 0];
B3to4Rotation=[1 0 0 ;0 1 0;0 0 1];
B3to4Translation=[L3 0 0];
B4to5Rotation=[1 0 0 ;0 1 0;0 0 1];
B4to5Translation=[L4 0 0];
B5to6Rotation=[1 0 0 ;0 0 -1;0 1 0];
B5to6Translation=[0 0 0];
%%
EtoARotation=[1 0 0 ;0 1 0;0 0 1];
EtoATranslation=[0 0 firsth];
%EtoATranslation=[0 0 1.5];
%EtoATranslation=[0 0 1.055];
%%
contact_stiffness=80000;
contact_damping=1000;
contact_point_radius=0.01;
% mu_k=0.800000000000000;
% mu_s=0.900000000000000;
% mu_vth=0.100000000000000;
% contact_stiffness=4000000;
% contact_damping=400000;
% contact_point_radius=0.008;
mu_k=1.500000000000000;
mu_s=1.600000000000000;
mu_vth=0.100000000000000;
%% IN THE NAME OF GOD
clear
clc
syms a b zf tf c h
eq1=-(b^2)/(4*h)==a;
eq2=a*(tf^2)+b*tf+c==zf;
eq=[eq1 eq2];
S1 = solve(eq,[a b]);
%a=-(c + 2*h - zf + 2*(h*(c + h - zf))^(1/2))/tf^2
%a=-(c + 2*h - zf - 2*(h*(c + h - zf))^(1/2))/tf^2
%b=(2*(h + (h*(c + h - zf))^(1/2)))/tf
%b=(2*(h - (h*(c + h - zf))^(1/2)))/tf

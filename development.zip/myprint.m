%%IN THE NAME OF ....
%%
function myprint(A)
if(A==1)
    disp('low priority');
elseif(A==2)
    disp('high priority');
elseif(A==3)
    disp('no');
end
%%IN THE NAME OF ....
%% Joint controller params
hip_servo_kp = 12500;
hip_servo_ki = 3500;
hip_servo_kd = 100;
knee_servo_kp = 10000;
knee_servo_ki = 2750;
knee_servo_kd = 75;
%%
ankle_servo_kd=50;
ankle_servo_ki=2000;
ankle_servo_kp=7500;
deriv_filter_coeff=1000;
max_torque=80;
%%joints
%joint_damping=1;
joint_limit_stiffness=1000;
join_limit_damping=100;
jointDamping = 1;
motion_time_constant = 0.001;

%%
joint_damping = 1;
joint_stiffness = 1;
motion_time_constant = 0.01;

%% Joint controller parameters
hip_servo_kp = 60;
hip_servo_ki = 10;
hip_servo_kd = 20;
knee_servo_kp = 60;
knee_servo_ki = 5;
knee_servo_kd = 10;
ankle_servo_kp = 20;
ankle_servo_ki = 4;
ankle_servo_kd = 8;
deriv_filter_coeff = 100;
max_torque = 20;

%% Electric motor parameters
motor_voltage = 24;
motor_resistance = 1;
motor_constant = 0.01;
motor_inertia = 0;
motor_damping = 0;
motor_inductance = 1.2e-6;
gear_ratio = 5;
Dens=100;

%%
motor_voltage = 24;
max_torque = 100;
hip_servo_kp = 600;
hip_servo_ki = 10;
hip_servo_kd = 20;

knee_servo_kp = 800;
knee_servo_ki = 2;
knee_servo_kd = 20;

ankle_servo_kp = 600;
ankle_servo_ki = 40;
ankle_servo_kd = 80;
joint_damping=0.001;
Back_emf=0.05;
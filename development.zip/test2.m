%% IN THE NAME OF GOD
clc
syms Ax Bx Dx Dy Ex Ey x y
%% finding D
eq1=(x-Ax)^2+(y-Ay)^2==15^2;
eq2=((Ay - By)/(Ax - Bx))*x-(Ay*Bx - Ax*By)/(Ax - Bx)==y;
eq=[eq1 eq2];
S1 = solve(eq,[x y]);
D1x=simplify(S1.x(1, 1));
D1y=simplify(S1.y(1, 1));
D2x=simplify(S1.x(2, 1));
D2y=simplify(S1.y(2, 1));
%% Finding C
eq1=(x-Ax)^2+(y-Ay)^2==53^2;
eq2=((Ay - By)/(Ax - Bx))*x-(Ay*Bx - Ax*By)/(Ax - Bx)==y;
eq=[eq1 eq2];
S1 = solve(eq,[x y]);
C1x=simplify(S1.x(1, 1));
C1y=simplify(S1.y(1, 1));
C2x=simplify(S1.x(2, 1));
C2y=simplify(S1.y(2, 1));
%% finding E
syms A2B
A2E=15;
B2E=sqrt(A2B^2-A2E^2);
eq1=(x-Ax)^2+(y-Ay)^2==15^2;
eq2=(x-Bx)^2+(y-By)^2==B2E^2;
eq=[eq1 eq2];
S1 = solve(eq,[x y]);
E1x=simplify(S1.x(1, 1));
E1y=simplify(S1.y(1, 1));
E2x=simplify(S1.x(2, 1));
E2y=simplify(S1.y(2, 1));
%% finding F
syms E2F
eq1=(x-Ax)^2+(y-Ay)^2==53^2;
eq2=(x-Ex)^2+(y-Ey)^2==E2F;
eq=[eq1 eq2];
S1 = solve(eq,[x y]);
F1x=simplify(S1.x(1, 1));
F1y=simplify(S1.y(1, 1));
F2x=simplify(S1.x(2, 1));
F2y=simplify(S1.y(2, 1));
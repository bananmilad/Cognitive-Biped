%% IN THE NAME OF GOD
clear
clc
syms Ax Ay Bx By x y B2E
%% finding F
eq1=(x-Ax)^2+(y-Ay)^2==15^2;
eq2=(x-Bx)^2+(y-By)^2==B2E^2;
eq=[eq1 eq2];
S1 = solve(eq,[x y]);
E1x=simplify(S1.x(1, 1));
E1y=simplify(S1.y(1, 1));
E2x=simplify(S1.x(2, 1));
E2y=simplify(S1.y(2, 1));
%%IN THE NAME OF ....
%%
%%Edge Finder..............................................................
function [Goal,Nomin] =SPlace_L(A,B,G)
ploton=0;
Ax=A(1);
Ay=A(2);
Bx=B(1);
By=B(2);
%%
D1x=Ax - 15*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 15*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D1y=Ay - 15*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 15*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D2x=Ax + 15*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 15*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D2y=Ay + 15*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 15*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D1=[D1x D1y];
D2=[D2x D2y];
V1=B-A;
V2=D1-A;
V3=D2-A;
if(sum(V1.*V2)>0)
    D=D1;
else
    D=D2;
end
%%
C1x=Ax - 53*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 53*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C1y=Ay - 53*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 53*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C2x=Ax + 53*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 53*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C2y=Ay + 53*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 53*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C1=[C1x C1y];
C2=[C2x C2y];
V1=B-A;
V2=C1-A;
V3=C2-A;
if(sum(V1.*V2)>0)
    C=C1;
else
    C=C2;
end
%%
A2B=sqrt((Ax-Bx)^2+(Ay-By)^2);
A2E=15;

if((A2B-15)<0.1)
    B2E=0.1;
else
    B2E=sqrt(A2B^2-A2E^2);
end

E1x=(225*Bx - 225*Ax - Ay*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + By*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax*Ay^2 + Ax*B2E^2 - Ax*Bx^2 - Ax^2*Bx + Ay^2*Bx + Ax*By^2 - B2E^2*Bx + Bx*By^2 + Ax^3 + Bx^3 - 2*Ax*Ay*By - 2*Ay*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E1y=(225*By - 225*Ay + Ax*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) - Bx*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax^2*Ay + Ay*B2E^2 + Ay*Bx^2 + Ax^2*By - Ay*By^2 - Ay^2*By - B2E^2*By + Bx^2*By + Ay^3 + By^3 - 2*Ax*Ay*Bx - 2*Ax*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E2x=(225*Bx - 225*Ax + Ay*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) - By*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax*Ay^2 + Ax*B2E^2 - Ax*Bx^2 - Ax^2*Bx + Ay^2*Bx + Ax*By^2 - B2E^2*Bx + Bx*By^2 + Ax^3 + Bx^3 - 2*Ax*Ay*By - 2*Ay*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E2y=(225*By - 225*Ay - Ax*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Bx*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax^2*Ay + Ay*B2E^2 + Ay*Bx^2 + Ax^2*By - Ay*By^2 - Ay^2*By - B2E^2*By + Bx^2*By + Ay^3 + By^3 - 2*Ax*Ay*Bx - 2*Ax*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E1=[E1x E1y];
E2=[E2x E2y];
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(B-A)')';
V2=E1-A;
V3=E2-A;
if(sum(V1.*V2)>0)
    E=E1;
else
    E=E2;
end
%%
Ex=E(1);
Ey=E(2);
A2F=53;
E2F=sqrt(A2F^2-A2E^2);
F1x=(2809*Ex - 2809*Ax - Ay*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*Ay^2 + Ey*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*E2F^2 - Ax*Ex^2 - Ax^2*Ex + Ay^2*Ex + Ax*Ey^2 - E2F^2*Ex + Ex*Ey^2 + Ax^3 + Ex^3 - 2*Ax*Ay*Ey - 2*Ay*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F1y=(2809*Ey - 2809*Ay + Ax*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax^2*Ay - Ex*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ay*E2F^2 + Ay*Ex^2 + Ax^2*Ey - Ay*Ey^2 - Ay^2*Ey - E2F^2*Ey + Ex^2*Ey + Ay^3 + Ey^3 - 2*Ax*Ay*Ex - 2*Ax*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F2x=(2809*Ex - 2809*Ax + Ay*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*Ay^2 - Ey*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*E2F^2 - Ax*Ex^2 - Ax^2*Ex + Ay^2*Ex + Ax*Ey^2 - E2F^2*Ex + Ex*Ey^2 + Ax^3 + Ex^3 - 2*Ax*Ay*Ey - 2*Ay*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F2y=(2809*Ey - 2809*Ay - Ax*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax^2*Ay + Ex*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ay*E2F^2 + Ay*Ex^2 + Ax^2*Ey - Ay*Ey^2 - Ay^2*Ey - E2F^2*Ey + Ex^2*Ey + Ay^3 + Ey^3 - 2*Ax*Ay*Ex - 2*Ax*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F1=[F1x F1y];
F2=[F2x F2y];
V1=E-B;
V2=E-F1;
V3=E-F2;
if(sum(V1.*V2)<0)
    F=F1;
else
    F=F2;
end
%% after finding D C E F
AB=B-A;
M=(A+B)/2;
norm1=sqrt(AB(1)^2+AB(2)^2);
V1=AB;
%% finding NG
GM=M-G;
V2=GM;
P1=sum(V1.*V2);
h=P1/norm1;
NG=G+AB*2*h/norm1;
G=NG;

%%
out=0;
region1=0;
region2=0;
region3=0;
region4=0;
%%
DC=C-D;
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(DC)')';
CG=G-C;
V2=CG;
if(sum(V1.*V2)>0) % point is on top
    if((A(1)-G(1))^2+(A(2)-G(2))^2<15^2)
        out=1; %1
    else
        if((A(1)-G(1))^2+(A(2)-G(2))^2>53^2)
            out=1; %1
        else
            AE=E-A;
            V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AE)')';
            AG=G-A;
            V2=AG;
            if(sum(V1.*V2)<0)
                out=0; %0
            else
                EF=F-E;
                V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(EF)')';
                EG=G-E;
                V2=EG;
                if(sum(V1.*V2)<0)
                    out=0; %0
                else
                    out=1; %1
                end
            end
        end
    end
else
    out=1; %1
end
%%
DC=C-D;
V1=DC;
DG=G-D;
V2=DG;
CG=G-C;
V3=CG;
P1=sum(V1.*V2);
P2=sum(V1.*V3);
if(P1*P2<0)
    region1=1;
else
end
EF=F-E;
V1=EF;
EG=G-E;
V2=EG;
FG=G-F;
V3=FG;
P1=sum(V1.*V2);
P2=sum(V1.*V3);
if(P1*P2<0)
    region3=1;
else
end
AD=D-A;
AE=E-A;
AG=G-A;
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AD)')';
V2=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AE)')';
V3=AG;
P1=sum(V1.*V3);
P2=sum(V2.*V3);
if((P1>0)&&(P2<0))
    region2=1;
else
end
AC=C-A;
AF=F-A;
AG=G-A;
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AC)')';
V2=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AF)')';
V3=AG;
P1=sum(V1.*V3);
P2=sum(V2.*V3);
if((P1>0)&&(P2<0))
    region4=1;
else
end
%%
if(region1==1)
    DC=C-D;
    DG=G-D;
    alpha=sum(DC.*DG)/(DC(1)^2+DC(2)^2);
    Nomin11=alpha*C+(1-alpha)*D;
    Nomin12=alpha*C+(1-alpha)*D;
else
    Nomin11=D;
    Nomin12=C;
end
if(region2==1)
    AE=E-A;
    norm1=sqrt(AE(1)^2+AE(2)^2);
    AG=G-A;
    norm2=sqrt(AG(1)^2+AG(2)^2);
    Nomin21=(AG/(norm2))*norm1+A;
    Nomin22=(AG/(norm2))*norm1+A;
else
    Nomin21=E;
    Nomin22=D;
end
if(region3==1)
    FE=E-F;
    FG=G-F;
    alpha=sum(FE.*FG)/(FE(1)^2+FE(2)^2);
    Nomin31=alpha*E+(1-alpha)*F;
    Nomin32=alpha*E+(1-alpha)*F;
else
    Nomin31=F;
    Nomin32=E;
end
if(region4==1)
    AF=F-A;
    norm1=sqrt(AF(1)^2+AF(2)^2);
    AG=G-A;
    norm2=sqrt(AG(1)^2+AG(2)^2);
    Nomin41=((AG/(norm2))*norm1)+A;
    Nomin42=((AG/(norm2))*norm1)+A;
else
    Nomin41=F;
    Nomin42=C;
end
Nomin=[Nomin11;Nomin12;Nomin21;Nomin22;Nomin31;Nomin32;Nomin41;Nomin42];
[k,dist] = Closest(Nomin,G);

if(out==1)
    Goal=Nomin(k,:);
else
    Goal=G;
end
%%
%% Finding N values
AB=B-A;
M=(A+B)/2;
norm1=sqrt(AB(1)^2+AB(2)^2);
V1=AB;
%% finding NC
CM=M-C;
V2=CM;
P1=sum(V1.*V2);
h=P1/norm1;
NC=C+AB*2*h/norm1;
C=NC;
%% Finding ND
DM=M-D;
V2=DM;
P1=sum(V1.*V2);
h=P1/norm1;
ND=D+AB*2*h/norm1;
D=ND;
%% Finding NE
EM=M-E;
V2=EM;
P1=sum(V1.*V2);
h=P1/norm1;
NE=E+AB*2*h/norm1;
E=NE;
%% Finding NF
FM=M-F;
V2=FM;
P1=sum(V1.*V2);
h=P1/norm1;
NF=F+AB*2*h/norm1;
F=NF;
%% finding NG
GM=M-G;
V2=GM;
P1=sum(V1.*V2);
h=P1/norm1;
NG=G+AB*2*h/norm1;
G=NG;
%% finding NGoal
GoalM=M-Goal;
V2=GoalM;
P1=sum(V1.*V2);
h=P1/norm1;
NGoal=Goal+AB*2*h/norm1;
Goal=NGoal;
%% finding Nomin11
Nomin11M=M-Nomin11;
V2=Nomin11M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin11=Nomin11+AB*2*h/norm1;
Nomin11=NNomin11;
%%
%% finding Nomin12
Nomin12M=M-Nomin12;
V2=Nomin12M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin12=Nomin12+AB*2*h/norm1;
Nomin12=NNomin12;
%%
%% finding Nomin21
Nomin21M=M-Nomin21;
V2=Nomin21M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin21=Nomin21+AB*2*h/norm1;
Nomin21=NNomin21;
%%
%% finding Nomin22
Nomin22M=M-Nomin22;
V2=Nomin22M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin22=Nomin22+AB*2*h/norm1;
Nomin22=NNomin22;
%%
%% finding Nomin31
Nomin31M=M-Nomin31;
V2=Nomin31M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin31=Nomin31+AB*2*h/norm1;
Nomin31=NNomin31;
%%
%% finding Nomin32
Nomin32M=M-Nomin32;
V2=Nomin32M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin32=Nomin32+AB*2*h/norm1;
Nomin32=NNomin32;
%%
%% finding Nomin41
Nomin41M=M-Nomin41;
V2=Nomin41M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin41=Nomin41+AB*2*h/norm1;
Nomin41=NNomin41;
%%
%% finding Nomin42
Nomin42M=M-Nomin42;
V2=Nomin42M;
P1=sum(V1.*V2);
h=P1/norm1;
NNomin42=Nomin42+AB*2*h/norm1;
Nomin42=NNomin42;
%%
Nomin=[Nomin11;Nomin12;Nomin21;Nomin22;Nomin31;Nomin32;Nomin41;Nomin42];
%%
if(ploton==1)
    figure
    plot(D(1),D(2),'rx')
    hold on
    plot(C(1),C(2),'rx')
    hold on
    plot(F(1),F(2),'rx')
    hold on
    plot(E(1),E(2),'rx')
    hold on
    plot(G(1),G(2),'s','Color','[0 0.5 0]')
    hold on
    plot(Goal(1),Goal(2),'s','Color','[0 0.5 0]')
    hold on
    plot(Nomin(1,1),Nomin(1,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(2,1),Nomin(2,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(3,1),Nomin(3,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(4,1),Nomin(4,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(5,1),Nomin(5,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(6,1),Nomin(6,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(7,1),Nomin(7,2),'o','Color','[0 0.5 0]')
    hold on
    plot(Nomin(8,1),Nomin(8,2),'o','Color','[0 0.5 0]')
end
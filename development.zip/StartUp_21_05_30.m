%%IN THE NAME OF GOD.......................................................
%%2 LEVEL ARCHITECTURE START UP............................................
clear
clc
%%
%%Starting Position........................................................
readyH=0;
START_POS;
%%ROBOT PARAMS.............................................................
HUBO_4_PARAM;
%%
%%FOOT
%%LOCATIONS(TEMP)..........................................................
T0l=[1 0 0 0;0 1 0 -0.24;0 0 1 0;0 0 0 1];
T0r=[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1];
TM=[1 0 0 0;0 1 0 -0.2;0 0 1 0;0 0 0 1];
FP(:,:,1)=T0l;
FP(:,:,2)=T0r;
FP(:,:,3)=TM;
h=0.75;
%% linear inverted pendulem
load('MPC.mat')
%% Torque Servo
ankle_servo_kd=50;
ankle_servo_ki=2000;
ankle_servo_kp=7500;
deriv_filter_coeff=1000;
max_torque=80;
%%joints
joint_damping=0.08;
%joint_damping=1;
joint_limit_stiffness=1000;
join_limit_damping=100;
%%
%motion_time_constant=0.1;
%%
tcstart=ones(4,4,100);
trstart=ones(4,4,100);
tlstart=ones(4,4,100);
for i=1:1:100
    tcstart(:,:,i)=[1 0 0 0;0 1 0 0;0 0 1 firsth;0 0 0 1];
    tlstart(:,:,i)=[1 0 0 0.12;0 1 0 -0.05;0 0 1 0.055;0 0 0 1];
    trstart(:,:,i)=[1 0 0 -0.12;0 1 0 -0.05;0 0 1 0.055;0 0 0 1];
end
load('T1.mat');
Tf=40; %simulation time
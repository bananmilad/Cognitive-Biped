% in the name of GOD
% start up CSD2............................................................
close
clear
clc
syms a11 a12 a13 a21 a22 a23 a31 a32 a33
syms b1 b2 b3
% syms k1 k2 k3
% syms g
k1=-1;
k2=-2;
k3=-3;
g=2;
A=[0 1 0;0 0 1;0 0 0];
B=[0;0;1];
K1=g*[k1 k2 k3];
K2=[k1 k2 k3];
EEE1=eig(A-B*K1);
EEE2=eig(A-B*K2);
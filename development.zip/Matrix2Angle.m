%%IN THE NAME OF ....
%%
%%Orientation to Transform matrix..........................................
function [A1f A2f A3f] = Matrix2Angle(T)%A1 Orientation on X, A2 on Y, A3 on Z
A1=ones(1,2);
A2=ones(1,2);
A3=ones(1,2);
if(abs(T(3,1))~=1)
    A2(1)=-asin(max(min(T(3,1),1),-1));
    A2(2)=pi-A2(1);
    A1(1)=atan2(T(3,2)/cos((A2(1))),T(3,3)/cos(A2(1)));
    A1(2)=atan2(T(3,2)/cos(A2(2)),T(3,3)/cos(A2(2)));
    A3(1)=atan2(T(2,1)/cos(A2(1)),T(1,1)/cos(A2(1)));
    A3(2)=atan2(T(2,1)/cos(A2(2)),T(1,1)/cos(A2(2)));
else
    A3(1)=0;
    if(T(3,1)==-1)
        A2(1)=pi/2;
        A1(1)=A3(1)+atan2(T(1,2),T(1,3));
    else
        A2(1)=-pi/2;
        A1(1)=-A3(1)+atan2(-T(1,2),-T(1,3));
    end
    A3(2)=A3(1);
    A2(2)=A2(1);
    A1(2)=A1(1);
end
A1f=A1(1);
A2f=A2(1);
A3f=A3(1);


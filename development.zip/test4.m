%% IN THE NAME OF GOD
clear
clc
syms Ax Ay Ex Ey x y E2F
%% finding F
eq1=(x-Ax)^2+(y-Ay)^2==53^2;
eq2=(x-Ex)^2+(y-Ey)^2==E2F^2;
eq=[eq1 eq2];
S1 = solve(eq,[x y]);
F1x=simplify(S1.x(1, 1));
F1y=simplify(S1.y(1, 1));
F2x=simplify(S1.x(2, 1));
F2y=simplify(S1.y(2, 1));
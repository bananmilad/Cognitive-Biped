% in the name of GOD
% RL8......................................................................
K=size(trainingStats.EpisodeReward);
L=0;
Succes=1:1:K;
t=1:1:K;
for i=1:1:K(1)
    if(trainingStats.EpisodeReward(i)>150)
        L=L+1;
    else
    end
    Succes(i)=L;
end
% in the name of GOD
% start up CSD2............................................................
close
clear
clc
%% Starting Position.......................................................
readyH=0;
START_POS;
%% ROBOT PARAMS............................................................
HUBO_4_PARAM_02;
%% FOOT
%%LOCATIONS(TEMP)..........................................................
T0l=[1 0 0 0;0 1 0 -0.24;0 0 1 0;0 0 0 1];
T0r=[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1];
TM=[1 0 0 0;0 1 0 -0.2;0 0 1 0;0 0 0 1];
FP(:,:,1)=T0l;
FP(:,:,2)=T0r;
FP(:,:,3)=TM;
h=0.75;
%% linear inverted pendulem
load('MPC.mat')
%% Torque Servo
ankle_servo_kd=50;
ankle_servo_ki=2000;
ankle_servo_kp=7500;
deriv_filter_coeff=1000;
max_torque=80;
%%joints
joint_damping=0.08;
%joint_damping=1;
joint_limit_stiffness=1000;
join_limit_damping=100;
%%
%motion_time_constant=0.1;
%%
tcstart=ones(4,4,100);
trstart=ones(4,4,100);
tlstart=ones(4,4,100);
for i=1:1:100
    tcstart(:,:,i)=[1 0 0 0;0 1 0 0;0 0 1 firsth;0 0 0 1];
    tlstart(:,:,i)=[1 0 0 0.12;0 1 0 -0.05;0 0 1 0.055;0 0 0 1];
    trstart(:,:,i)=[1 0 0 -0.12;0 1 0 -0.05;0 0 1 0.055;0 0 0 1];
end
load('T1.mat');
% open system
open_system('CDS6') % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%% agent parameters
obsN=11; % number of observations. position and speed
        % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
actN=2; % number of actions. locations in x and y
        % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
interactN=1/5; % how many time interact with environment in a second
               % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
actorL=5e-04; % actors learning rate % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>
criticL=1e-03; % critics learning rate % changable>>>>>>>>>>>>>>>>>>>>>>>>>
finalR=900000; % after geting this reward level we are done % changable>>>>>
doTraining = true; % train or use trained agents % changable>>>>>>>>>>>>>>
cellN=200; % number of neurons in one layer or complexity of networks
           % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%% create agnet environment
obsInfo = rlNumericSpec([obsN 1]);
obsInfo.Name = 'vision';
obsInfo.Description = 'x dx';
numObservations = obsInfo.Dimension(1);
%actInfo = rlNumericSpec([actN 1]);
actInfo = rlNumericSpec([actN 1],'LowerLimit',-50,'UpperLimit',50);
        % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
actInfo.Name = 'force';
%actInfo.UpperLimit=100; % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
numActions = actInfo.Dimension(1);
env = rlSimulinkEnv('CDS6','CDS6/HIGH LEVEL/Agent',... % changable>>>>>>>>>
    obsInfo,actInfo);
%% simulation parameter
Ts = 1/interactN;
Tf = 40; % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%% fix random seed
rng('shuffle')
%% create agent critic
statePath = [
    featureInputLayer(numObservations,'Normalization','none','Name',...
    'observation')
    fullyConnectedLayer(cellN,'Name','CriticStateFC1')
    reluLayer('Name','CriticRelu1')
    fullyConnectedLayer(cellN,'Name','CriticStateFC2')];

actionPath = [
    featureInputLayer(numActions,'Normalization','none','Name','action')
    fullyConnectedLayer(cellN,'Name','CriticActionFC1',...
    'BiasLearnRateFactor',0)];

commonPath = [
    additionLayer(2,'Name','add')
    reluLayer('Name','CriticCommonRelu')
    fullyConnectedLayer(1,'Name','CriticOutput')];

criticNetwork = layerGraph(statePath);
criticNetwork = addLayers(criticNetwork,actionPath);
criticNetwork = addLayers(criticNetwork,commonPath);
    
criticNetwork = connectLayers(criticNetwork,'CriticStateFC2','add/in1');
criticNetwork = connectLayers(criticNetwork,'CriticActionFC1','add/in2');
criticOptions = rlRepresentationOptions('LearnRate',criticL,...
'GradientThreshold',1);
critic = rlQValueRepresentation(criticNetwork,obsInfo,actInfo,...
    'Observation',{'observation'},'Action',{'action'},criticOptions);
%% create agent actor
actorPath = [
    featureInputLayer(numObservations,'Normalization','none','Name','observation')
    fullyConnectedLayer(cellN,'Name','ActorFC1')
    reluLayer('Name','ActorRelu1')
    fullyConnectedLayer(cellN,'Name','ActorFC2')
    reluLayer('Name','ActorRelu2')
    fullyConnectedLayer(actN,'Name','ActorFC3')
    tanhLayer('Name','ActorTanh1')
    scalingLayer('Name','ActorScaling','Scale',max(actInfo.UpperLimit))];
actorNetwork = layerGraph(actorPath);
actorOptions = rlRepresentationOptions('LearnRate',actorL,...
'GradientThreshold',1);
actor = rlDeterministicActorRepresentation(actorNetwork,obsInfo,actInfo,...
    'Observation',{'observation'},'Action',{'ActorScaling'},actorOptions);
%% create agent actor and critic
agentOptions = rlDDPGAgentOptions(...
    'SampleTime',Ts,...
    'TargetSmoothFactor',1e-3,...
    'ExperienceBufferLength',1e6,...
    'MiniBatchSize',128);
agentOptions.NoiseOptions.Variance = 4;
agentOptions.NoiseOptions.VarianceDecayRate = 1e-5;
agent = rlDDPGAgent(actor,critic,agentOptions);
%% training options
maxepisodes = 2000;
maxsteps = ceil(Tf/Ts);
trainingOptions = rlTrainingOptions(...
    'MaxEpisodes',maxepisodes,...
    'MaxStepsPerEpisode',maxsteps,...
    'ScoreAveragingWindowLength',5,...
    'Verbose',false,...
    'Plots','training-progress',...
    'StopTrainingCriteria','AverageReward',...
    'StopTrainingValue',finalR,...
    'SaveAgentCriteria','EpisodeReward',...
    'SaveAgentValue',finalR);
%% training
if doTraining    
    % Train the agent.
    trainingStats = train(agent,env,trainingOptions);
else
    % Load the pretrained agent for the example.
    load('savedAgents/Agent59.mat','agent')
end
%%IN THE NAME OF ....
%%
%%Place Finder.............................................................
function [Goal,Nomin] =PlaceL(A,B,C,D,E,F,G)
out=0;
region1=0;
region2=0;
region3=0;
region4=0;
%%
DC=C-D;
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(DC)')';
CG=G-C;
V2=CG;
if(sum(V1.*V2)>0) % point is on top
    if((A(1)-G(1))^2+(A(2)-G(2))^2<15^2)
        out=1; %1
    else
        if((A(1)-G(1))^2+(A(2)-G(2))^2>53^2)
            out=1; %1
        else
            AE=E-A;
            V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AE)')';
            AG=G-A;
            V2=AG;
            if(sum(V1.*V2)<0)
                out=0; %0
            else
                EF=F-E;
                V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(EF)')';
                EG=G-E;
                V2=EG;
                if(sum(V1.*V2)<0)
                    out=0; %0
                else
                    out=1; %1
                end
            end
        end
    end
else
    out=1; %1
end
%%
DC=C-D;
V1=DC;
DG=G-D;
V2=DG;
CG=G-C;
V3=CG;
P1=sum(V1.*V2);
P2=sum(V1.*V3);
if(P1*P2<0)
    region1=1;
else
end
EF=F-E;
V1=EF;
EG=G-E;
V2=EG;
FG=G-F;
V3=FG;
P1=sum(V1.*V2);
P2=sum(V1.*V3);
if(P1*P2<0)
    region3=1;
else
end
AD=D-A;
AE=E-A;
AG=G-A;
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AD)')';
V2=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AE)')';
V3=AG;
P1=sum(V1.*V3);
P2=sum(V2.*V3);
if((P1>0)&&(P2<0))
    region2=1;
else
end
AC=C-A;
AF=F-A;
AG=G-A;
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AC)')';
V2=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(AF)')';
V3=AG;
P1=sum(V1.*V3);
P2=sum(V2.*V3);
if((P1>0)&&(P2<0))
    region4=1;
else
end
%%
if(region1==1)
   DC=C-D;
   DG=G-D;
   alpha=sum(DC.*DG)/(DC(1)^2+DC(2)^2);
   Nomin11=alpha*C+(1-alpha)*D;
   Nomin12=alpha*C+(1-alpha)*D;
else
    Nomin11=D;
    Nomin12=C;
end
if(region2==1)
   AE=E-A;
   norm1=sqrt(AE(1)^2+AE(2)^2);
   AG=G-A;
   norm2=sqrt(AG(1)^2+AG(2)^2);
   Nomin21=(AG/(norm2))*norm1;
   Nomin22=(AG/(norm2))*norm1;
else
    Nomin21=E;
    Nomin22=F;
end
if(region3==1)
   FE=E-F;
   FG=G-F;
   alpha=sum(FE.*FG)/(FE(1)^2+FE(2)^2);
   Nomin31=alpha*E+(1-alpha)*F;
   Nomin32=alpha*E+(1-alpha)*F;
else
    Nomin31=F;
    Nomin32=E;
end
if(region4==1)
   AF=F-A;
   norm1=sqrt(AF(1)^2+AF(2)^2);
   AG=G-A;
   norm2=sqrt(AG(1)^2+AG(2)^2);
   Nomin41=(AG/(norm2))*norm1;
   Nomin42=(AG/(norm2))*norm1;
else
    Nomin41=F;
    Nomin42=C;
end
Nomin=[Nomin11;Nomin12;Nomin21;Nomin22;Nomin31;Nomin32;Nomin41;Nomin42];
[k,dist] = dsearchn(Nomin,G);

if(out==1)
    Goal=Nomin(k,:);
else
    Goal=G;
end
figure
plot(D(1),D(2),'rx')
hold on
plot(C(1),C(2),'rx')
hold on
plot(F(1),F(2),'rx')
hold on
plot(E(1),E(2),'rx')
hold on
plot(G(1),G(2),'s','Color','[0 0.5 0]')
hold on
plot(Goal(1),Goal(2),'s','Color','[0 0.5 0]')
hold on
plot(Nomin(1,1),Nomin(1,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(2,1),Nomin(2,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(3,1),Nomin(3,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(4,1),Nomin(4,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(5,1),Nomin(5,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(6,1),Nomin(6,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(7,1),Nomin(7,2),'o','Color','[0 0.5 0]')
hold on
plot(Nomin(8,1),Nomin(8,2),'o','Color','[0 0.5 0]')
% in the name of GOD
% start up CSD2............................................................
close
clear
clc
%%
Utility;
%% agent parameters
obsN=5; % number of observations. position and speed
% changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
actN=2; % number of actions. locations in x and y
% changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
interactN=1/5; % how many time interact with environment in a second
% changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
actorL=5e-04; % actors learning rate % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>
criticL=1e-03; % critics learning rate % changable>>>>>>>>>>>>>>>>>>>>>>>>>
SmoothFactor=1e-3;                   % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>
BufferLength=1e6;                      % changable>>>>>>>>>>>>>>>>>>>>>>>>>
BatchSize=128;                         % changable>>>>>>>>>>>>>>>>>>>>>>>>>
finalR=20000; % after geting this reward level we are done % changable>>>>>
doTraining = true; % train or use trained agents % changable>>>>>>>>>>>>>>
cellN=50; % number of neurons in one layer or complexity of networks
% changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%% simulation parameter
Ts = 1/interactN;
Tf = 300; % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
maxepisodes = 4000; % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Training=1; % Continue to training or not
% changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if(Training==1)
    %% create agnet environment
    obsInfo = rlNumericSpec([obsN 1]);
    obsInfo.Name = 'vision';
    numObservations = obsInfo.Dimension(1);
    %actInfo = rlNumericSpec([actN 1]);
    actInfo = rlNumericSpec([actN 1],'LowerLimit',-50,'UpperLimit',50);
    % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    actInfo.Name = 'force';
    %actInfo.UpperLimit=50; % changable>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    numActions = actInfo.Dimension(1);
    env = rlSimulinkEnv('RL_Model_02','RL_Model_02/Agent',... % changable>>>>>>>>>
        obsInfo,actInfo);
    
    
    
    
    %% create agent critic
    statePath = [
        featureInputLayer(numObservations,'Normalization','none','Name',...
        'observation')
        fullyConnectedLayer(cellN,'Name','CriticStateFC1')
        reluLayer('Name','CriticRelu1')
        fullyConnectedLayer(cellN,'Name','CriticStateFC2')];
    
    actionPath = [
        featureInputLayer(numActions,'Normalization','none','Name','action')
        fullyConnectedLayer(cellN,'Name','CriticActionFC1',...
        'BiasLearnRateFactor',0)];
    
    commonPath = [
        additionLayer(2,'Name','add')
        reluLayer('Name','CriticCommonRelu')
        fullyConnectedLayer(1,'Name','CriticOutput')];
    
    criticNetwork = layerGraph(statePath);
    criticNetwork = addLayers(criticNetwork,actionPath);
    criticNetwork = addLayers(criticNetwork,commonPath);
    
    criticNetwork = connectLayers(criticNetwork,'CriticStateFC2','add/in1');
    criticNetwork = connectLayers(criticNetwork,'CriticActionFC1','add/in2');
    criticOptions = rlRepresentationOptions('LearnRate',criticL,...
        'GradientThreshold',1);
    critic = rlQValueRepresentation(criticNetwork,obsInfo,actInfo,...
        'Observation',{'observation'},'Action',{'action'},criticOptions);
    %% create agent actor
    actorPath = [
        featureInputLayer(numObservations,'Normalization','none','Name','observation')
        fullyConnectedLayer(cellN,'Name','ActorFC1')
        reluLayer('Name','ActorRelu1')
        fullyConnectedLayer(cellN,'Name','ActorFC2')
        reluLayer('Name','ActorRelu2')
        fullyConnectedLayer(actN,'Name','ActorFC3')
        tanhLayer('Name','ActorTanh1')
        scalingLayer('Name','ActorScaling','Scale',max(actInfo.UpperLimit))];
    actorNetwork = layerGraph(actorPath);
    actorOptions = rlRepresentationOptions('LearnRate',actorL,...
        'GradientThreshold',1);
    actor = rlDeterministicActorRepresentation(actorNetwork,obsInfo,actInfo,...
        'Observation',{'observation'},'Action',{'ActorScaling'},actorOptions);
    %% create agent actor and critic
    agentOptions = rlDDPGAgentOptions(...
        'SampleTime',Ts,...
        'TargetSmoothFactor',SmoothFactor,...
        'ExperienceBufferLength',BufferLength,...
        'DiscountFactor',0.99,...
        'MiniBatchSize',BatchSize);
    agentOptions.NoiseOptions.Variance = 6;
    agentOptions.NoiseOptions.VarianceDecayRate = 1e-5;
    agent_01 = rlDDPGAgent(actor,critic,agentOptions);
    %% training options
    maxsteps = ceil(Tf/Ts);
    trainingOptions = rlTrainingOptions(...
        'MaxEpisodes',maxepisodes,...
        'MaxStepsPerEpisode',maxsteps,...
        'ScoreAveragingWindowLength',5,...
        'Verbose',false,...
        'Plots','training-progress',...
        'StopTrainingCriteria','AverageReward',...
        'StopTrainingValue',finalR,...
        'SaveAgentCriteria','EpisodeCount',...
        'SaveAgentValue',maxepisodes);
    %'SaveAgentCriteria','EpisodeReward',...
    %%
%     USE_PRE_TRAINED_MODEL = true; % Set to true, to use pre-trained
%     agentOptions.ResetExperienceBufferBeforeTraining = not(USE_PRE_TRAINED_MODEL);
%     load('Learned_Agent_05.mat');
%     
%     %agent = saved_agent;
%     trainingStats = train(agent_01, env, trainingOptions);
    %% training
    if doTraining
        % Train the agent.
        trainingStats = train(agent_01,env,trainingOptions);
    else
        % Load the pretrained agent for the example.
        load('savedAgents/Agent59.mat','agent')
    end
end
%%IN THE NAME OF ....
%%
%%Orientation to Transform matrix..........................................
function T = Angle2Matrix(x,y,z,A1, A2, A3)%A1 Orientation on X, A2 on Y, A3 on Z
T=[cos(A2)*cos(A3) cos(A3)*sin(A1)*sin(A2)-cos(A1)*sin(A3) sin(A1)*sin(A3)+cos(A1)*cos(A3)*sin(A2) x;
cos(A2)*sin(A3) cos(A1)*cos(A3)+sin(A1)*sin(A2)*sin(A3) cos(A1)*sin(A2)*sin(A3)-cos(A3)*sin(A1) y;
-sin(A2) cos(A2)*sin(A1) cos(A1)*cos(A2) z;
0 0 0 1];
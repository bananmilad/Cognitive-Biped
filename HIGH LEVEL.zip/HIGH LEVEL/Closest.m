%%IN THE NAME OF ....
%%
%%Edge Finder..............................................................
function [k,dist] =Closest(Nomin,G)
P=size(Nomin);
F=P(1);
V=zeros(F,2);
D=zeros(F,1);
for i=1:1:F
    V(i,:)=Nomin(i,:)-G;
    D(i,:)=sqrt(V(i,1)^2+V(i,2)^2);
end
[dist,index]=min(D);
k=index;

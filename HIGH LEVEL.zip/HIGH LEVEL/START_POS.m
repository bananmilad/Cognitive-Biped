%%IN THE NAME OF ....
%%
%%HUBO_4 START PARAM.......................................................
if(readyH==1)%%standing straigt
    firsth=1.06;
    Qstart=[0;0;0;0;pi/2;0;0;0;0;0;pi/2;0];
    q_l(6)=Qstart(1);
    q_l(5)=Qstart(2);
    q_l(4)=Qstart(3);
    q_l(3)=Qstart(4);
    q_l(2)=Qstart(5);
    q_l(1)=Qstart(6);
    q_r(6)=Qstart(7);
    q_r(5)=Qstart(8);
    q_r(4)=Qstart(9);
    q_r(3)=Qstart(10);
    q_r(2)=Qstart(11);
    q_r(1)=Qstart(12);
else
    firsth=0.81;
    Qstart=[0;0.852;-1.649;0.796;pi/2;0;0;0.852;-1.649;0.796;pi/2;0];
    q_l(6)=Qstart(1);
    q_l(5)=Qstart(2);
    q_l(4)=Qstart(3);
    q_l(3)=Qstart(4);
    q_l(2)=Qstart(5);
    q_l(1)=Qstart(6);
    q_r(6)=Qstart(7);
    q_r(5)=Qstart(8);
    q_r(4)=Qstart(9);
    q_r(3)=Qstart(10);
    q_r(2)=Qstart(11);
    q_r(1)=Qstart(12);
end
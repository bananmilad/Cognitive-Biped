%%IN THE NAME OF ....
%%
%%Edge Finder..............................................................
function [D,C,E,F] =Edge(A,B)
Ax=A(1);
Ay=A(2);
Bx=B(1);
By=B(2);
%%
D1x=Ax - 15*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 15*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D1y=Ay - 15*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 15*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D2x=Ax + 15*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 15*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D2y=Ay + 15*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 15*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
D1=[D1x D1y];
D2=[D2x D2y];
V1=B-A;
V2=D1-A;
V3=D2-A;
if(sum(V1.*V2)>0)
    D=D1;
else
    D=D2;
end
%%
C1x=Ax - 53*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 53*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C1y=Ay - 53*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) + 53*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C2x=Ax + 53*Ax*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 53*Bx*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C2y=Ay + 53*Ay*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2) - 53*By*(1/(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2))^(1/2);
C1=[C1x C1y];
C2=[C2x C2y];
V1=B-A;
V2=C1-A;
V3=C2-A;
if(sum(V1.*V2)>0)
    C=C1;
else
    C=C2;
end
%%
A2B=sqrt((Ax-Bx)^2+(Ay-By)^2);
A2E=15;
B2E=sqrt(A2B^2-A2E^2);
E1x=(225*Bx - 225*Ax - Ay*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + By*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax*Ay^2 + Ax*B2E^2 - Ax*Bx^2 - Ax^2*Bx + Ay^2*Bx + Ax*By^2 - B2E^2*Bx + Bx*By^2 + Ax^3 + Bx^3 - 2*Ax*Ay*By - 2*Ay*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E1y=(225*By - 225*Ay + Ax*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) - Bx*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax^2*Ay + Ay*B2E^2 + Ay*Bx^2 + Ax^2*By - Ay*By^2 - Ay^2*By - B2E^2*By + Bx^2*By + Ay^3 + By^3 - 2*Ax*Ay*Bx - 2*Ax*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E2x=(225*Bx - 225*Ax + Ay*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) - By*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax*Ay^2 + Ax*B2E^2 - Ax*Bx^2 - Ax^2*Bx + Ay^2*Bx + Ax*By^2 - B2E^2*Bx + Bx*By^2 + Ax^3 + Bx^3 - 2*Ax*Ay*By - 2*Ay*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E2y=(225*By - 225*Ay - Ax*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Bx*((Ay^2 - 2*Ay*By - B2E^2 + 30*B2E + Bx^2 - 2*Ax*Bx + By^2 + Ax^2 - 225)*(- Ay^2 + 2*Ay*By + B2E^2 + 30*B2E - Bx^2 + 2*Ax*Bx - By^2 - Ax^2 + 225))^(1/2) + Ax^2*Ay + Ay*B2E^2 + Ay*Bx^2 + Ax^2*By - Ay*By^2 - Ay^2*By - B2E^2*By + Bx^2*By + Ay^3 + By^3 - 2*Ax*Ay*Bx - 2*Ax*Bx*By)/(2*(Ay^2 - 2*Ay*By + Bx^2 - 2*Ax*Bx + By^2 + Ax^2));
E1=[E1x E1y];
E2=[E2x E2y];
V1=([cos(pi/2) -sin(pi/2);sin(pi/2) cos(pi/2)]*(B-A)')';
V2=E1-A;
V3=E2-A;
if(sum(V1.*V2)>0)
    E=E1;
else
    E=E2;
end
%%
Ex=E(1);
Ey=E(2);
A2F=53;
E2F=sqrt(A2F^2-A2E^2);
F1x=(2809*Ex - 2809*Ax - Ay*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*Ay^2 + Ey*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*E2F^2 - Ax*Ex^2 - Ax^2*Ex + Ay^2*Ex + Ax*Ey^2 - E2F^2*Ex + Ex*Ey^2 + Ax^3 + Ex^3 - 2*Ax*Ay*Ey - 2*Ay*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F1y=(2809*Ey - 2809*Ay + Ax*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax^2*Ay - Ex*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ay*E2F^2 + Ay*Ex^2 + Ax^2*Ey - Ay*Ey^2 - Ay^2*Ey - E2F^2*Ey + Ex^2*Ey + Ay^3 + Ey^3 - 2*Ax*Ay*Ex - 2*Ax*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F2x=(2809*Ex - 2809*Ax + Ay*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*Ay^2 - Ey*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax*E2F^2 - Ax*Ex^2 - Ax^2*Ex + Ay^2*Ex + Ax*Ey^2 - E2F^2*Ex + Ex*Ey^2 + Ax^3 + Ex^3 - 2*Ax*Ay*Ey - 2*Ay*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F2y=(2809*Ey - 2809*Ay - Ax*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ax^2*Ay + Ex*((Ay^2 - 2*Ay*Ey - E2F^2 + 106*E2F + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2 - 2809)*(- Ay^2 + 2*Ay*Ey + E2F^2 + 106*E2F - Ex^2 + 2*Ax*Ex - Ey^2 - Ax^2 + 2809))^(1/2) + Ay*E2F^2 + Ay*Ex^2 + Ax^2*Ey - Ay*Ey^2 - Ay^2*Ey - E2F^2*Ey + Ex^2*Ey + Ay^3 + Ey^3 - 2*Ax*Ay*Ex - 2*Ax*Ex*Ey)/(2*(Ay^2 - 2*Ay*Ey + Ex^2 - 2*Ax*Ex + Ey^2 + Ax^2));
F1=[F1x F1y];
F2=[F2x F2y];
V1=E-B;
V2=E-F1;
V3=E-F2;
if(sum(V1.*V2)<0)
    F=F1;
else
    F=F2;
end
%%
AB=B-A;
M=(A+B)/2;
norm1=sqrt(AB(1)^2+AB(2)^2);
V1=AB;
%% finding NC
CM=M-C;
V2=CM;
P1=sum(V1.*V2);
h=P1/norm1;
NC=C+AB*2*h/norm1;
C=NC;
%% Finding ND
DM=M-D;
V2=DM;
P1=sum(V1.*V2);
h=P1/norm1;
ND=D+AB*2*h/norm1;
D=ND;
%% Finding NE
EM=M-E;
V2=EM;
P1=sum(V1.*V2);
h=P1/norm1;
NE=E+AB*2*h/norm1;
E=NE;
%% Finding NF
FM=M-F;
V2=FM;
P1=sum(V1.*V2);
h=P1/norm1;
NF=F+AB*2*h/norm1;
F=NF;